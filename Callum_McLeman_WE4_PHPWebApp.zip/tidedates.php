<?php  

/**********************************************************
* Author: Callum McLeman
* Assignment: WE4.1 PHP Web App Assignment, Digital Skills Academy
* Student ID: D15128641   ( or DT7003 )
* Date : 2016/05/18
* Ref: website link to code referenced or the book, authors name and page number
some look ups and adapted examples etc from  http://www.w3schools.com/html/default.asp
and http://www.w3schools.com/php/
***********************************************************/
/*chkdate is a class.php file 
contains the class chkdate that
validates the date input
*/
include ("tidalTimes.class.php"); 
include ("dateErrorCheck.Class.php");
// gets for port location and date
$port1 = $_GET['port'];
$tidedate1 = $_GET['tidedate'];
//var_dump($port1);
//var_dump($tidedate1);
//create date manipulation object
$objValidate = new chkdate($tidedate1);
//go check the date for errors
/// paint job on main page!
if (! $objValidate->validateDate($tidedate1))
{
	//bad date input, inform & ret to page
?>
<!DOCTYPE html>
<html>
	<head>
		<title>
			PHP Assignment.
		</title>
		<!-- css pointer/setup -->
		<link rel="stylesheet" type="text/css" href="assignment.css">
	</head>
	<body>
  		<div id="header">
  			<img src="images/moons.jpg">
  			<h1>Tidal Times</h1>
  		</div>
  		<div id="content">
  			<form action="assignment1.html">
  				<p>Invalid Date!</p>
  				<input type='submit' value='Re-Enter'/>
  			</form>
  		</div>
   	</body>
 </html>
<?php
} 
else
{
	//go calc the 4 tides for the input date.
	//get/make  date/time object
	$objTideFinder = new tidalTimes($port1,$tidedate1);
	//setter not used, but in class, as construct took care of it above.
	//$tidedate1 = $objValidate->getdate();
	$tideTimeTableArray = $objTideFinder->getTideTimes($port1,$tidedate1);
	
	//prepare output
	// another shuffle?  make function/metodf call from geTideTimes
	$tempDate = substr ($tidedate1 , 0 , 2 ) . "-" .
			        substr ( $tidedate1 , 3 ,2 ) . "-" .
			        substr ( $tidedate1 , 6 , 4 );
	$day=strftime("%A",strtotime($tempDate));
	$month=strftime("%B",strtotime($tempDate));
	//get day number, lose any leading zero
	$dayNumber= (int) substr( $tidedate1 , 0 ,2 );
	// sort the little  st, nd, rd  for 'proper' dates 
	if($dayNumber == 1 || $dayNumber == 21 || $dayNumber == 31)
	{
		$littleMadame = "st.";
	} 
	elseif ($dayNumber == 2 || $dayNumber == 22)
	{
		$littleMadame = "nd.";
	}
	else
	{
		$littleMadame = "th.";
	}
	//make top info/data header  lables
	$portHeading =  "Port of " .ucfirst($port1) . ".";
	$dataHeadingOne = "The Tides for " . " $day the " ;
	$dataHeadingOne = $dataHeadingOne . $dayNumber . $littleMadame ." of  " . $month . " are :" ; 
	//var_dump($tideTimeTableArray);
	// fire out a wee table
	$dataLine = " " ;
	$dataLine = " " . $dataLine . substr($tideTimeTableArray[0],11,14) . "   " ;
	$dataLine = $dataLine . substr($tideTimeTableArray[1],11,14) . "   " ;
	$dataLine = $dataLine . substr($tideTimeTableArray[2],11,14) . "   " ;
	$dataLine = $dataLine . substr($tideTimeTableArray[3],11,14) ;
	// get the image for port location
	switch($port1)
	{
		case 'cork':
			$pushPic = '<img src="images/portcork.jpg">' ;
			break;
		case 'dublin':
			
			$pushPic = '<img src="images/portdublin.jpg">' ;
			break;
		case 'dingle':
			
			$pushPic = '<img src="images/portdingle.jpg">' ;
			break;
		default:
			$pushPic = '<img src="images/portkillybegs.jpg">' ;
		//killybegs
	}
?>
<!DOCTYPE html>
<html>
	<head>
		<title>
			PHP Assignment.
		</title>
		<!-- css pointer/setup -->
		<link rel="stylesheet" type="text/css" href="assignment.css">
	</head>
	<body>
  		<div id="header">
  			<img src="images/moons.jpg">
  			<h2>Tidal Times</h2>
  		</div>
  		<div id="content">
  			<h4> <?php echo ($portHeading) ?> </h4>
  			<p> <?php echo ($dataHeadingOne . "  " . $dataLine); ?></p>
  			 <?php echo($pushPic) ; ?>
			<form action="assignment1.html">
  				<p>Check Another ?</p>
  				<input type='submit' value=' Go '/>
  			</form>
  			<div id="content">


  			</div>
  		</div>
  	</body>
 </html>
<?php
}
// endif - valid date input
?>



