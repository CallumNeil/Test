<?php
/**********************************************************
* Author: Callum McLeman
* Assignment: WE4.1 PHP Web App Assignment, Digital Skills Academy
* Student ID: D15128641   ( or DT7003 )
* Date : 2016/05/18
* Ref: website link to code referenced or the book, authors name and page number -
* some look ups and adapted examples etc from  http://www.w3schools.com/html/default.asp
and http://www.w3schools.com/php/ 
***********************************************************/
/* class file for calculating tides for a given date
returns an array of tides
12hrs 25min each high tide interval (12*60*60)+(25*60) = tot seconds
12hrs 25min each low tide interval   43,200 + 1500 = 44,700 seconds
6hrs 12 1/2 mins between each hi/lo tide.
*/
//set date of port tide reference reading
// inputs from html via tidedates.php  $portKey, $findTideDate
class tidalTimes
{
	//just str's 4 now
	private $tideDateIn ="2016-05-08 01:23:00";
	private $portKey = "cork";
	// wake up the captain!
	public function __construct($portKey, $tidedateIn)
	{
		//$strTideDateRef=date_create($tidedate1);
		//tidedatein has only the date as a str, must add later time
		$this->tidedateIn = $tidedateIn;
		$this->portKey = $portKey;
	}
	//end func const.
	//setter - for date & port just to have it !
	public function setTidein($tideDateIn)
	{
		$this->tideDateIn = $tideDateIn;
	}
	//setter - for port
	public function setPortIn($portKey)
	{
		$this->portKey = $portKey;
	}
	//getter 4 date
	public function getTidein()
	{
		return $this->tideDateIn;
	}
	// getter 4 port
	public function getPortIn()
	{
		return $this->portKey;
	}
	//get port tide time ref; all are first & low tide of the day
	//  of the reference date (2016-05-08 01:23:00).
	public function getTideTimes($portKey,$tideDateIn)
	{
		//set first low tide ref. for the selected port - fake database referance
		switch ($portKey)
		{
    		case "cork":
       			$tideDateRef=date_create("2016-05-08 01:23:00");
        		break;
    		case "dingle":
       		 	$tideDateRef=date_create("2016-05-08 00:10:00");
        		break;
    		case "dublin":
        		$tideDateRef=date_create("2016-05-08 01:09:00");
       			break;
   	   		default:
    			//killybegs
        		$tideDateRef=date_create("2016-05-08 01:18:00");
		} 
		//end switch
		//set comparison tide time to almost midnight of the date input
		//Tidedatein only had the date string part, must now slap on a time
		// and turn to a date variable type.
		$tempDate = substr ($tideDateIn , 0 , 2 ) . "-" .
			        substr ( $tideDateIn , 3 ,2 ) . "-" .
			        substr ( $tideDateIn , 6 , 4 );
		$findTideDate =date_create($tempDate . " 23:59:00");
		//init array and element contents
		$timeTideTable = array();
		// wee indicator for low and high tides
		$tideNumber = "1";
		//var_dump($tideDateRef);
		//var_dump($findTideDate);
		//
		while(date_timestamp_get($tideDateRef) < date_timestamp_get($findTideDate))
		{
			//zip through tides
			//and send array back for output.
			//augment each time/tide interval by a tide ..
			switch($tideNumber)
			{
				case "1":
					$timeTideTable[0] = date_format($tideDateRef,"Y-m-d H:i:s") . " Low.";
					$tideNumber = "2";
					break;
				case "2":
					$timeTideTable[1] = date_format($tideDateRef,"Y-m-d H:i:s") . " High.";
					$tideNumber = "3";
					break;
				case "3":
					$timeTideTable[2] = date_format($tideDateRef,"Y-m-d H:i:s" ) . " Low." ;
					$tideNumber = "4";
					break;
				case "4":
					$timeTideTable[3] = date_format($tideDateRef,"Y-m-d H:i:s") . " High.";
					$tideNumber = "1";
					break;

				default:
					//nada
			}
			$tideDateRef = $tideDateRef->add(new DateInterval('PT06H12M30S'));
			//echo date_format($tideDateRef,"Y-m-d H:i:s") . "<br>";

		}
		// while date not midnight of input date
		// sort ascending the table 
		// due to the lunar day/month date condition on exit, but all tides will be in for $tideDateIn
		sort($timeTideTable);
		//var_dump($timeTideTable);
		return $timeTideTable;
	}
	//end func geTideTimes
}
//end class tidaltimes
?>



