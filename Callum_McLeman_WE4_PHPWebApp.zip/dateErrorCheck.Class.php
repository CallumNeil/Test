<?php
/**********************************************************
* Author: Callum McLeman
* Assignment: WE4.1 PHP Web App Assignment, Digital Skills Academy
* Student ID: D15128641   ( or DT7003 )
* Date : 2016/05/18
* Ref: website link to code referenced or the book, authors name and page number
some look ups and adapted examples etc from  http://www.w3schools.com/html/default.asp
and http://www.w3schools.com/php/
***********************************************************/
/*
*  Class file for taking a date and validating
*  Returns true on a good / valid date, false otherwise
*/
class chkDate
{
	private $month =0;
	private $day = 0;
	private $year=0;
	private $dateToValidate = "01/01/2016";
	//private $validatedDate = date("Y-m-d");
	function __construct($dateToChk)
	{
		$this->dateToValidate = $dateToChk ;
	}
	// end constructr
	//set up a setter - though done on construct may be obsolete here.
	public function setDate($dateToChk)
	{
		$this->dateToValidate = $dateToChk ;
	}
	//end setter func
	//set up a getter for the date too.
	public function getDate()
	{
		return $this->dateToValidate ;
	}
	//endfunc getter

/* cut up and put string in to month, day, year using
 substr (  $string , int $start [, int $length ] )
and validate the date with checkdate(). ret true if valid 
date input - input format is = 08/05/2016. dd/mm/yyyy
*/
	public function validateDate($dateToValidate)
	{
        //date was input as  'dd/mm/yyyy' doctor it for php 
        //var_dump($dateToValidate);
        $day = 0;
        $month=0;
        $year=0;
		$day = intval(substr ($dateToValidate , 0 , 2 ));
		$month = intval( substr ( $dateToValidate , 3 ,2 ));
		$year= intval( substr ( $dateToValidate , 6 ,4 ));
		//make input date in the fmt of yyyy-mm-dd
		$validateTideDate = substr ($dateToValidate , 0 , 2 ) . "-" .
					        substr ( $dateToValidate , 3 ,2 ) . "-" .
					        substr ( $dateToValidate , 6 , 4 );

		if (! checkdate ( $month ,  $day , $year ))
		{
			//oops!
			return false;
   		}
   		else
   		{
   			
   			//is it => todays date?
   			$today = strtotime( date("Y-m-d"));
   			//var_dump($today);
   			$this->validatedDate = strtotime($validateTideDate);
   			//var_dump($validatedDate);
   			if ($this->validatedDate >= $today)
   			{
   				return true;
   				// all ok....
   			} 
   			else
   			{
   				return false;
   				//oops!
   			}
   		}
	}
}
//end class
?>
